import java.io.Buffer
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.LinkedList;
import java.util.Scanner;

public class participante {

 public static void main(String[] args) {
Scanner teclado = new Scanner(System.in);

String nom,correo, nom2, correo2;

int opcion=1;

while(opcion != 0){
	System.out.println(" menu de opciones ");
	System.out.println("1- registrar usuario ");
	System.out.println("2- agregar usuario ");
	System.out.println("0- cerrar programa ");
	System.out.println("ingrese una opcion ");
	opcion = teclado.nextInt();
	System.out.println("");
	
	
	switch(opcion){
		case 1:
			System.out.println("selecciono registrar usuario ");
		
			System.out.println(" Ingrese su nombre ");

			nom = teclado.nextLine();

			System.out.println(" Ingrese su correo ");

			correo = teclado.nextLine();

			System.out.println( " Usted se llama " + nom + "y su correo es " + correo );

			String participante = ("nombre:"+nom + "correo:"+ correo);
			String LeerParticipante="";

			try {
				FileWriter fichero = new FileWriter ("datosdue�o.txt");
						fichero.write(participante);
						fichero.close();
			}catch (Exception ex) { ex.printStackTrace(); }


			try {
				FileReader lector= new FileReader ("datosdue�os.txt");
				BufferedReader BR = new BufferedReader(lector);
				LeerParticipante=BR.readLine();
			}catch (Exception ex) { ex.printStackTrace(); }

			break;
			
			
			
		case 2: 
			System.out.println("selecciono agregar un usuario");
		
			System.out.println(" Ingrese nombre de otro participante ");

			nom2 = teclado.nextLine();

			System.out.println(" Ingrese el correo de otro participante ");

			correo2 = teclado.nextLine();

			System.out.println( " Usted se llama " + nom2 + "y su correo es " + correo2 );

			String participantes = ("nombre:"+nom2 + "correo:"+ correo2);
			String LeerParticipantes="";

			try {
				FileWriter fichero = new FileWriter ("datosparticipantes.txt");
						fichero.write(participantes);
						fichero.close();
			}catch (Exception ex) { ex.printStackTrace(); }


			try {
				FileReader lector= new FileReader ("datosparticipantes.txt");
				BufferedReader BR = new BufferedReader(lector);
				LeerParticipantes=BR.readLine();
			}catch (Exception ex) { ex.printStackTrace(); }
			
			break;
			
		
		case 3:
			System.out.println("selecciono cerrar programa, hasta pronto!");
			break;

		 }

		 }
		 
			
		

			
	}
}


 

 

