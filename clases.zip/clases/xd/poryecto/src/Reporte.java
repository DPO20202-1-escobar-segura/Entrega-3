import participante;
import java.util.concurrent.TimeUnit;


public class Reporte extends actividad{
	public actividad act;
	public int darTiempo() {
		return act.tiempo;
	}
	public long tiempo_promedio_por_dia(long dias) {
		long def = act.fechafinal.getTime - act.fechainicial.getTime;
		TimeUnit time= TimeUnit.DAYS;
		long def_dias = act.fechaFinal.getDayOfMonth() - act.fechaInicial.getDayOfMonth();
		long difference = time.convert(def,TimeUnit.MILISECONDS);
		long promedio = difference/def_dias;
		return promedio;
		
	}
}
